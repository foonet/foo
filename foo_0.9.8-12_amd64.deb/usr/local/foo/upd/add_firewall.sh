#!/bin/bash

source /etc/profile.d/foo.sh
if [ ! -e "$FOO/data/firewall" ]; then
    mkdir -p $FOO/data/firewall
    chmod 770 $FOO/data/firewall

    cp $FOO/install/rhel/firewall/* \
        $FOO/data/firewall/
    chmod 660 $FOO/data/firewall/*

    source $FOO/conf/foo.conf
    if [ -z "$FIREWALL_SYSTEM" ]; then
        echo "FIREWALL_SYSTEM='iptables'" \
            >> $FOO/conf/foo.conf
    fi
fi
