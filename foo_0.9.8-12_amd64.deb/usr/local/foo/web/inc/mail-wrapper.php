#!/usr/local/foo/php/bin/php
<?php

if (empty($argv[1])) {
    echo "Error: not enough arguments\n";
    exit(3);
}

$options = getopt("s:f:");


define('NO_AUTH_REQUIRED',true);
include("/usr/local/foo/web/inc/main.php");

// Set system language
exec (FOO_CMD . "foo-list-sys-config json", $output, $return_var);
$data = json_decode(implode('', $output), true);
if (!empty( $data['config']['LANGUAGE'])) {
    $_SESSION['language'] = $data['config']['LANGUAGE'];
} else {
    $_SESSION['language'] = 'en';
}
require_once('/usr/local/foo/web/inc/i18n/'.$_SESSION['language'].'.php');

// Define vars
//$from = 'Foo Control Panel <support@'.gethostname().'>';
$from = 'Foo Control Panel <support@bounce.foonet.org>';
$to = $argv[3]."\n";
$subject = $argv[2]."\n";
$mailtext = file_get_contents("php://stdin");

// Send email
if ((!empty($to)) && (!empty($subject))) {
    send_email($to,$subject,$mailtext,$from);
}

?>
