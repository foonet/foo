<?php
define('FOO_CMD', '/usr/bin/sudo /usr/local/foo/bin/');

if (isset($_POST['user']) || isset($_POST['hash'])) {

    // Authentication
    $auth_code = 1;
    if (empty($_POST['hash'])) {
        $v_user = escapeshellarg($_POST['user']);
        $v_password = escapeshellarg($_POST['password']);
        exec(FOO_CMD ."foo-check-user-password ".$v_user." ".$v_password." '".$_SERVER["REMOTE_ADDR"]."'",  $output, $auth_code);
    } else {
        $key = '/usr/local/foo/data/keys/' . basename($_POST['hash']);
        if (file_exists($key)) {
            $auth_code = '0';
        }
    }

    if ($auth_code != 0 ) {
        echo 'Error: authentication failed';
        exit;
    }

    // Check user permission to use API
    if ($_POST['user'] != 'admin') {
        echo 'Error: only admin is allowed to use API';
        exit;
    }
    
    
    // Prepare arguments
    if (isset($_POST['cmd'])) $cmd = escapeshellarg($_POST['cmd']);
    if (isset($_POST['arg1'])) $arg1 = escapeshellarg($_POST['arg1']);
    if (isset($_POST['arg2'])) $arg2 = escapeshellarg($_POST['arg2']);
    if (isset($_POST['arg3'])) $arg3 = escapeshellarg($_POST['arg3']);
    if (isset($_POST['arg4'])) $arg4 = escapeshellarg($_POST['arg4']);
    if (isset($_POST['arg5'])) $arg5 = escapeshellarg($_POST['arg5']);
    if (isset($_POST['arg6'])) $arg6 = escapeshellarg($_POST['arg6']);
    if (isset($_POST['arg7'])) $arg7 = escapeshellarg($_POST['arg7']);
    if (isset($_POST['arg8'])) $arg8 = escapeshellarg($_POST['arg8']);
    if (isset($_POST['arg9'])) $arg9 = escapeshellarg($_POST['arg9']);

 // Build query
    $cmdquery = FOO_CMD.$cmd." ";
     
     if(!empty($arg1)){
                     $cmdquery = $cmdquery.$arg1." "; }
     if(!empty($arg2)){
                     $cmdquery = $cmdquery.$arg2." "; }
     if(!empty($arg3)){
                     $cmdquery = $cmdquery.$arg3." "; }
     if(!empty($arg4)){
                     $cmdquery = $cmdquery.$arg4." "; }
     if(!empty($arg5)){
                     $cmdquery = $cmdquery.$arg5." "; }
     if(!empty($arg6)){
                     $cmdquery = $cmdquery.$arg6." "; }
     if(!empty($arg7)){
                     $cmdquery = $cmdquery.$arg7." "; }
     if(!empty($arg8)){
                     $cmdquery = $cmdquery.$arg8." "; }
     if(!empty($arg9)){
                     $cmdquery = $cmdquery.$arg9; }

   // Run query
    exec ($cmdquery, $output, $return_var);
    
    if ((!empty($_POST['returncode'])) && ($_POST['returncode'] == 'yes')) {
        echo $return_var;
    } else {
        if (($return_var == 0) && (empty($output))) {
            echo "OK";
        } else {
            echo implode("\n",$output)."\n";
        }
    }
}

?>
