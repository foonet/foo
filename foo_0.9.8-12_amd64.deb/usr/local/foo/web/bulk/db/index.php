<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

$database = $_POST['database'];
$action = $_POST['action'];

if ($_SESSION['user'] == 'admin') {
    switch ($action) {
        case 'delete': $cmd='foo-delete-database';
            break;
        case 'suspend': $cmd='foo-suspend-database';
            break;
        case 'unsuspend': $cmd='foo-unsuspend-database';
            break;
        default: header("Location: /list/db/"); exit;
    }
} else {
    switch ($action) {
        case 'delete': $cmd='foo-delete-database';
            break;
        default: header("Location: /list/db/"); exit;
    }
}

foreach ($database as $value) {
    $value = escapeshellarg($value);
    exec (FOO_CMD.$cmd." ".$user." ".$value, $output, $return_var);
}

header("Location: /list/db/");
