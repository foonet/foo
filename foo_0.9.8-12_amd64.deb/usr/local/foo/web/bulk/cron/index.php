<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

$job = $_POST['job'];
$action = $_POST['action'];

if ($_SESSION['user'] == 'admin') {
    switch ($action) {
        case 'delete': $cmd='foo-delete-cron-job';
            break;
        case 'suspend': $cmd='foo-suspend-cron-job';
            break;
        case 'unsuspend': $cmd='foo-unsuspend-cron-job';
            break;
        case 'delete-cron-reports': $cmd='foo-delete-cron-reports';
            exec (FOO_CMD.$cmd." ".$user, $output, $return_var);
            $_SESSION['error_msg'] = __('Cronjob email reporting has been successfully diabled');
            unset($output);
            header("Location: /list/cron/");
            exit;
            break;
        case 'add-cron-reports': $cmd='foo-add-cron-reports';
            exec (FOO_CMD.$cmd." ".$user, $output, $return_var);
            $_SESSION['error_msg'] = __('Cronjob email reporting has been successfully enabled');
            unset($output);
            header("Location: /list/cron/");
            exit;
            break;
        default: header("Location: /list/cron/"); exit;
    }
} else {
    switch ($action) {
        case 'delete': $cmd='foo-delete-cron-job';
            break;
        case 'delete-cron-reports': $cmd='foo-delete-cron-reports';
            exec (FOO_CMD.$cmd." ".$user, $output, $return_var);
            $_SESSION['error_msg'] = __('Cronjob email reporting has been successfully diabled');
            unset($output);
            header("Location: /list/cron/");
            exit;
            break;
        case 'add-cron-reports': $cmd='foo-add-cron-reports';
            exec (FOO_CMD.$cmd." ".$user, $output, $return_var);
            $_SESSION['error_msg'] = __('Cronjob email reporting has been successfully enabled');
            unset($output);
            header("Location: /list/cron/");
            exit;
            break;
        default: header("Location: /list/cron/"); exit;
    }
}

foreach ($job as $value) {
    $value = escapeshellarg($value);
    exec (FOO_CMD.$cmd." ".$user." ".$value." no", $output, $return_var);
    $restart = 'yes';
}

if (!empty($restart)) {
    exec (FOO_CMD."foo-restart-cron", $output, $return_var);
}

header("Location: /list/cron/");
