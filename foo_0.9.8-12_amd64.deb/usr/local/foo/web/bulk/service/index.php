<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

$service = $_POST['service'];
$action = $_POST['action'];

if ($_SESSION['user'] == 'admin') {
    switch ($action) {
        case 'stop': $cmd='foo-stop-service';
            break;
        case 'start': $cmd='foo-start-service';
            break;
        case 'restart': $cmd='foo-restart-service';
            break;
        default: header("Location: /list/services/"); exit;
    }

    if ((!empty($_POST['system'])) && ($action == 'restart')) {
        exec (FOO_CMD."foo-restart-system yes", $output, $return_var);
        $_SESSION['error_srv'] = 'The system is going down for reboot NOW!';
        unset($output);
        header("Location: /list/services/");
        exit;
    }

    foreach ($service as $value) {
        $value = escapeshellarg($value);
        exec (FOO_CMD.$cmd." ".$value, $output, $return_var);
    }
}

header("Location: /list/services/");
