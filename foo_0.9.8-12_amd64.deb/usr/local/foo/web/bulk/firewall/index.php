<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

// Main include
include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

// Check user
if ($_SESSION['user'] != 'admin') {
    header("Location: /list/user");
    exit;
}


$rule = $_POST['rule'];
$action = $_POST['action'];

switch ($action) {
    case 'delete': $cmd='foo-delete-firewall-rule';
        break;
    case 'suspend': $cmd='foo-suspend-firewall-rule';
        break;
    case 'unsuspend': $cmd='foo-unsuspend-firewall-rule';
        break;
    default: header("Location: /list/firewall/"); exit;
}

foreach ($rule as $value) {
    $value = escapeshellarg($value);
    exec (FOO_CMD.$cmd." ".$value, $output, $return_var);
    $restart = 'yes';
}

header("Location: /list/firewall/");
