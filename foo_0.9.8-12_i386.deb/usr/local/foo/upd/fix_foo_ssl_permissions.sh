#!/bin/bash

chown root:mail /usr/local/foo/ssl/*
chmod 660 /usr/local/foo/ssl/*
