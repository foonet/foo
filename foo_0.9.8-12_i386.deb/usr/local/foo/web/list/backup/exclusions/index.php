<?php
session_start();
$TAB = 'BACKUP EXCLUSIONS';

// Main include
include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

// Header
include($_SERVER['DOCUMENT_ROOT'].'/templates/header.html');

// Panel
top_panel($user,$TAB);

// Data
exec (FOO_CMD."foo-list-user-backup-exclusions $user json", $output, $return_var);
$data = json_decode(implode('', $output), true);
unset($output);
include($_SERVER['DOCUMENT_ROOT'].'/templates/admin/list_backup_exclusions.html');

// Back uri
$_SESSION['back'] = $_SERVER['REQUEST_URI'];

// Footer
include($_SERVER['DOCUMENT_ROOT'].'/templates/footer.html');
