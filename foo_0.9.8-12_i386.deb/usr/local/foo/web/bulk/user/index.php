<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

$user = $_POST['user'];
$action = $_POST['action'];

if ($_SESSION['user'] == 'admin') {
    switch ($action) {
        case 'delete': $cmd='foo-delete-user'; $restart = 'no';
            break;
        case 'suspend': $cmd='foo-suspend-user'; $restart = 'no';
            break;
        case 'unsuspend': $cmd='foo-unsuspend-user'; $restart = 'no';
            break;
        case 'update counters': $cmd='foo-update-user-counters';
            break;
        case 'rebuild': $cmd='foo-rebuild-user'; $restart = 'no';
            break;
        case 'rebuild web': $cmd='foo-rebuild-web-domains'; $restart = 'no';
            break;
        case 'rebuild dns': $cmd='foo-rebuild-dns-domains'; $restart = 'no';
            break;
        case 'rebuild mail': $cmd='foo-rebuild-mail-domains';
            break;
        case 'rebuild db': $cmd='foo-rebuild-databases';
            break;
        case 'rebuild cron': $cmd='foo-rebuild-cron-jobs';
            break;
        default: header("Location: /list/user/"); exit;
    }
} else {
    switch ($action) {
        case 'update counters': $cmd='foo-update-user-counters';
            break;
        default: header("Location: /list/user/"); exit;
    }
}

foreach ($user as $value) {
    $value = escapeshellarg($value);
    exec (FOO_CMD.$cmd." ".$value." ".$restart, $output, $return_var);
    $changes = 'yes';
}

if ((!empty($restart)) && (!empty($changes))) {
    exec (FOO_CMD."foo-restart-web", $output, $return_var);
    exec (FOO_CMD."foo-restart-dns", $output, $return_var);
    exec (FOO_CMD."foo-restart-cron", $output, $return_var);
}

header("Location: /list/user/");
