<?php
// Init
error_reporting(NULL);
ob_start();
session_start();

include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

$domain = $_POST['domain'];
$action = $_POST['action'];

if ($_SESSION['user'] == 'admin') {
    switch ($action) {
        case 'delete': $cmd='foo-delete-web-domain';
                        $cmd_dns='foo-delete-dns-domain';
                        $cmd_mail='foo-delete-mail-domain';
            break;
        case 'suspend': $cmd='foo-suspend-web-domain';
                        $cmd_dns='foo-suspend-dns-domain';
                        $cmd_mail='foo-suspend-mail-domain';
            break;
        case 'unsuspend': $cmd='foo-unsuspend-web-domain';
                        $cmd_dns='foo-unsuspend-dns-domain';
                        $cmd_mail='foo-unsuspend-mail-domain';
            break;
        default: header("Location: /list/web/"); exit;
    }
} else {
    switch ($action) {
        case 'delete': $cmd='foo-delete-web-domain';
                        $cmd_dns='foo-delete-dns-domain';
                        $cmd_mail='foo-delete-mail-domain';
            break;
        default: header("Location: /list/web/"); exit;
    }
}

foreach ($domain as $value) {
    // WEB
    $value = escapeshellarg($value);
    exec (FOO_CMD.$cmd." ".$user." ".$value." no", $output, $return_var);
    $restart_web = 'yes';

    // DNS
    if ($return_var == 0) {
        exec (FOO_CMD."foo-list-dns-domain ".$user." ".$value." json", $output, $lreturn_var);
        if ($lreturn_var == 0 ) {
            exec (FOO_CMD.$cmd_dns." ".$user." ".$value." no", $output, $return_var);
            $restart_dns = 'yes';
        }
    }

    // Mail
    if ($return_var == 0) {
        exec (FOO_CMD."foo-list-mail-domain ".$user." ".$value." json", $output, $lreturn_var);
        if ($lreturn_var == 0 ) {
            exec (FOO_CMD.$cmd_mail." ".$user." ".$value." no", $output, $return_var);
        }
    }
}

if (!empty($restart_web)) {
    exec (FOO_CMD."foo-restart-web", $output, $return_var);
}

if (!empty($restart_dns)) {
    exec (FOO_CMD."foo-restart-dns", $output, $return_var);
}

header("Location: /list/web/");
